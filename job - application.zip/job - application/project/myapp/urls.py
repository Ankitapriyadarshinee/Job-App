from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from myapp import views


urlpatterns = [
    path("",views.index,name='index'),
    path('customer/' ,views.customer,name='customer'),
    path('courier/' ,views.courier ),
    
    path('sign-in/' ,auth_views.LoginView.as_view(template_name='sign_in.html')),
    path('sign-out/' ,auth_views.LogoutView.as_view(next_page='/')),

    path('sign-up/',views.sign_up),
    path('job/',views.job,name='job'),
]