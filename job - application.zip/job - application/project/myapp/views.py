from django.shortcuts import  render, redirect
from django.contrib.auth.models import User,auth 
from django.contrib.auth import authenticate
from myapp import forms
# Create your views here.


def index(request):
    return render(request,'index.html')

# @login_required()
def customer(request):
   
    return render(request,'customer.html' )

# @login_required()
def courier(request):
    return render(request,'courier.html')

# def sign_up(request):
    
#     return render(request,'sign_up.html')

def sign_up(request):
    if request.method=="POST":
        username= request.POST['username']
        first_name= request.POST['first_name']
        last_name= request.POST['last_name']
        email= request.POST['email']
        password1= request.POST['password1'] 

        if User.objects.filter(username=username).first():
          return render(request, 'sign_up.html')
        data = User.objects.create_user(username=username,first_name=first_name,last_name=last_name, email=email)
        data.save()  
    
    return render(request, 'sign_up.html')


def job(request):
    return render(request,'job.html')

